Innovate News Block for Moodle 3.0 (and beyond):

Introduction
------------

This block allows to see the headlines news to a Moodle dashbord to add the block in dashboard  by the participants of the moodle login.

How dedication News in moodle?
---------------------------------

Admin have a rights to  add,edit and delete the content of the News forms in innovate news

Installation:
01) In site administration block click on Site Administration->plugins->install plugins
01) Drag the zipfile to put in zip package in file picker of install plugin from zip file.
03) To install the plugin to submit by click on Install plugin fronm the zip file. 
04) Go to the \admin page and allow the block to be installed
05) Input the Description (for single line for flashnews), and status of displaying of innovate news.
06) I recommend that the field not be required, so it can  visible to all users.
08) Click on the Save Changes button
13) Add the Innovate news block to your page to see a list of those news to display as marquee. 

Features
--------

This block is intended to be used only by site admin, so students aren't going to
see it and their news views. However, block can be configured to show
scroll news to students too.

  Dedication of admin:
  Admin can view the news as well as can add,edit and delete the marquee news.

  Dedication of a student:
  Student can view the marquee of flash news.


This block can display a block in the site page, only enable the blocks in course page.

All texts in English .

Support
-------
Support is offered in English  in these forum discussions:

  English discussion: http://moodle.org/mod/forum/discuss.php?d=10948

Code repository: https://bitbucket.org/ciceidev/moodle_block_dedication
Issues: https://bitbucket.org/ciceidev/moodle_block_dedication/issues

Credits
-------

This block was developed by arun.
First version for Moodle 3.0 by arun. Updated and improved version
